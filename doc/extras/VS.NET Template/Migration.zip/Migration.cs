﻿using System.Data;
using Migrator.Framework;

namespace $rootnamespace$
{
    [Migration($year$)]
    public class $fileinputname$ : Migration
    {
        public override void Up()
        {
        }

        public override void Down()
        {
        }
    }
}